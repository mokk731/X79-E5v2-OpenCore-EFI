# OpenCore_X79_X99_Xeon_E5_2650v2
OpenCore EFI for X79 Mainboard and CPU xeon E5 2650v2 RX470
